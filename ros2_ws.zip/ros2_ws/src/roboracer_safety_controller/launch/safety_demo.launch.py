from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    return LaunchDescription([
        Node(
            package='roboracer_safety_controller',
            executable='distance_sensor_node',
            name='distance_sensor'
        ),
        Node(
            package='roboracer_safety_controller',
            executable='safety_controller_node',
            name='safety_controller'
        ),
        Node(
            package='roboracer_safety_controller',
            executable='vehicle_monitor_node',
            name='vehicle_monitor'
        ),
    ])

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Range


class DistanceSensorNode(Node):
    """
    Publishes simulated front obstacle distance data on /front_distance using Range message type.
    Sequence simulates an obstacle approaching and moving away.
    """
    def __init__(self):
        super().__init__('distance_sensor_node')
        self.publisher_ = self.create_publisher(Range, '/front_distance', 10)
        self.timer = self.create_timer(1.0, self.timer_callback)
        
        # Distance values covering > 1.0m, 0.5m-1.0m, and < 0.5m
        self.distance_sequence = [2.0, 1.5, 1.2, 0.8, 0.6, 0.3, 0.1, 0.4, 0.7, 1.1, 1.8]
        self.index = 0

    def timer_callback(self):
        msg = Range()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = 'front_range_sensor'
        msg.radiation_type = Range.ULTRASOUND
        msg.field_of_view = 0.1
        msg.min_range = 0.1
        msg.max_range = 5.0
        
        msg.range = float(self.distance_sequence[self.index])
        
        self.publisher_.publish(msg)
        self.get_logger().info(f'Published Distance: {msg.range:.2f} m')
        
        self.index = (self.index + 1) % len(self.distance_sequence)


def main(args=None):
    rclpy.init(args=args)
    node = DistanceSensorNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()

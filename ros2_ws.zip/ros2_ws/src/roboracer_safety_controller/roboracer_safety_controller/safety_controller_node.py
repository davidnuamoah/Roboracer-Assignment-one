import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Range
from geometry_msgs.msg import Twist


class SafetyControllerNode(Node):
    """
    Subscribes to /front_distance and publishes velocity command on /cmd_vel based on exact safety rules.
    """
    def __init__(self):
        super().__init__('safety_controller_node')
        self.subscription = self.create_subscription(
            Range,
            '/front_distance',
            self.distance_callback,
            10
        )
        self.publisher_ = self.create_publisher(Twist, '/cmd_vel', 10)

    def distance_callback(self, msg: Range):
        dist = msg.range
        cmd = Twist()

        # Required safety control logic
        if dist >= 1.0:
            cmd.linear.x = 1.0
        elif 0.5 <= dist < 1.0:
            cmd.linear.x = 0.3
        else:
            cmd.linear.x = 0.0

        cmd.angular.z = 0.0
        self.publisher_.publish(cmd)
        self.get_logger().info(f'Distance: {dist:.2f} m -> Commanded Speed: {cmd.linear.x:.1f} m/s')


def main(args=None):
    rclpy.init(args=args)
    node = SafetyControllerNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist


class VehicleMonitorNode(Node):
    """
    Subscribes to /cmd_vel and prints vehicle state: DRIVE, SLOW, or STOP.
    """
    def __init__(self):
        super().__init__('vehicle_monitor_node')
        self.subscription = self.create_subscription(
            Twist,
            '/cmd_vel',
            self.velocity_callback,
            10
        )

    def velocity_callback(self, msg: Twist):
        speed = msg.linear.x
        
        if abs(speed - 1.0) < 1e-3:
            state = "DRIVE"
        elif abs(speed - 0.3) < 1e-3:
            state = "SLOW"
        elif abs(speed - 0.0) < 1e-3:
            state = "STOP"
        else:
            state = "UNKNOWN"

        self.get_logger().info(f'Vehicle State: [{state}] | Speed: {speed:.1f} m/s')


def main(args=None):
    rclpy.init(args=args)
    node = VehicleMonitorNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()

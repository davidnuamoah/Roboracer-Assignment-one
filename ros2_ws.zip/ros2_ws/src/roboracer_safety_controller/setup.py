from setuptools import find_packages, setup
import os
from glob import glob

package_name = 'roboracer_safety_controller'

setup(
    name=package_name,
    version='0.0.1',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Student',
    maintainer_email='student@giu-berlin.de',
    description='RoboRacer safety controller package',
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'distance_sensor_node = roboracer_safety_controller.distance_sensor_node:main',
            'safety_controller_node = roboracer_safety_controller.safety_controller_node:main',
            'vehicle_monitor_node = roboracer_safety_controller.vehicle_monitor_node:main',
        ],
    },
)
